AU-Assets-Swapper packs
=======================

Each subfolder of AUAS_Data is a pack. Category folders go inside a pack:

  AUAS_Data/MyPack/Sprites/
  AUAS_Data/MyPack/Audio/
  ...

Categories: Sprites, Textures, Audio, Fonts, Shaders, Materials, Prefabs
File names must match the asset name (without extension).

In-game: F6 = pack menu, F5 = rescan, F7 = pick mode.
Old flat assets were moved to AUAS_Data/legacy/.
